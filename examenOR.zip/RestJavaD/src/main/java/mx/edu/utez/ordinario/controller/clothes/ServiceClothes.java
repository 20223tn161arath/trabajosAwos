package mx.edu.utez.ordinario.controller.clothes;

import mx.edu.utez.ordinario.model.clothes.BeanClothes;
import mx.edu.utez.ordinario.model.clothes.DaoClothes;
import mx.edu.utez.ordinario.utils.Response;

import javax.jws.WebParam;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/api")
public class ServiceClothes {

    @GET
    @Path("/clothes")
    @Produces(value = {"application/json"})
    public Response<List> getAll(){
        return new DaoClothes().findAll();
    }
    @GET
    @Path("/clothes/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response<BeanClothes> getOne(@PathParam("id") Long id){ return new DaoClothes().findOne(id); }
    @POST
    @Path("/clothes")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response<BeanClothes> save(@WebParam BeanClothes clothes) { return new DaoClothes().save(clothes); }
}
