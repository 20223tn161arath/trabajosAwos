package mx.edu.utez.ordinario.model.clothe.types;
import mx.edu.utez.ordinario.model.Repository;
import mx.edu.utez.ordinario.model.clothes.BeanClothes;
import mx.edu.utez.ordinario.model.clothes.DaoClothes;
import mx.edu.utez.ordinario.utils.MySQLConnection;
import mx.edu.utez.ordinario.utils.Response;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoClotheType implements Repository<BeanClothes> {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    MySQLConnection mysql = new MySQLConnection();

    private final String GET_CLOTHES_TYPES = "SELECT * FROM clothe_types";
    private final String GET_CLOTHE_TYPES = "SELECT * FROM clothe_types WHERE id = ?";
    private final String INSERT_CLOTHE_TYPES = "INSERT INTO clothe_types(id,name) VALUES(?,?,?,?,?,?,?,?)";
    private final String UPDATE_CLOTHE_TYPES = "UPDATE SET name = ? WHERE id = ?";

    @Override
    public Response<List> findAll() {
        List<BeanClothes> clothes_typesList = new ArrayList<>();
        Response<List> response = new Response<>();
        BeanClothes clothes_type = null;
        try {
            conn = mysql.getConnection();
            String query = GET_CLOTHES_TYPES;
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()) {
                clothes_type = new BeanClothes();
                clothes_type.setId(rs.getInt("id"));
                clothes_type.setName(rs.getString("Name"));

                clothes_typesList.add(clothes_type);
            }
            if (clothes_typesList.isEmpty()) {
                response.setError(false);
                response.setStatus(200);
                response.setMessage("Nothing Found");
                response.setData(null);
            } else {
                response.setError(false);
                response.setStatus(200);
                response.setMessage("OK");
                response.setData(clothes_typesList);
            }
        } catch (SQLException e) {
            Logger.getLogger(DaoClothes.class.getName())
                    .log(Level.SEVERE, "Error -> findAll_DaoClothes_types " + e.getMessage());
            response.setError(true);
            response.setStatus(400);
            response.setMessage("Error -> " + e.getMessage());
            response.setData(null);
        } finally {
            mysql.close(conn, pstm, rs);
        }
        return response;
    }




    @Override
    public Response<BeanClothes> findOne(Long id) {
        Response<BeanClothes> response = new Response<>();
        BeanClothes clothes = null;
        try {
            conn = mysql.getConnection();
            String query = GET_CLOTHE_TYPES;
            pstm = conn.prepareStatement(query);
            pstm.setLong(1,id);
            rs = pstm.executeQuery();
            if(rs.next()){
                clothes = new BeanClothes();
                clothes.setId(rs.getInt("id"));
                clothes.setName(rs.getString("Name"));
                clothes.setPrice(rs.getInt("price"));
                clothes.setSize(rs.getInt("size"));
                clothes.setBrand(rs.getString("brand"));
                clothes.setStock(rs.getInt("stock"));
                clothes.setCloth_type(rs.getString("cloth_type"));
                clothes.setCreated_at(rs.getString("Created_at"));
                clothes.setStatus(rs.getInt("status"));
                clothes.setCategory_id(rs.getInt("category_id"));
                clothes.setClothe_type_id(rs.getInt("clothe_type_id"));

                response.setError(false);
                response.setStatus(200);
                response.setMessage("OK");
                response.setData(clothes);
            }else{
                response.setError(false);
                response.setStatus(200);
                response.setMessage("Nothing Found");
                response.setData(null);
            }

        }catch (SQLException e){
            Logger.getLogger(DaoClothes.class.getName())
                    .log(Level.SEVERE, "Error -> findOne_DaoClothes_type " + e.getMessage());

            response.setError(true);
            response.setStatus(400);
            response.setMessage("Error -> " + e.getMessage());
            response.setData(null);
        }finally {
            mysql.close(conn, pstm, rs);
        }
        return response;
    }

    @Override
    public Response<BeanClothes> save(BeanClothes object) {
        return null;
    }

    @Override
    public Response<BeanClothes> update(BeanClothes object) {
        return null;
    }

    @Override
    public Response<BeanClothes> delete(Long id) {
        return null;
    }
}
