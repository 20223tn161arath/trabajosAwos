package mx.edu.utez.ordinario.model;

import mx.edu.utez.ordinario.utils.Response;

import java.util.List;

public interface Repository<T> {
    Response<List> findAll();
    Response<T> findOne(Long id);
    Response<T> save(T object);
    Response<T> update(T object);
    Response<T> delete(Long id);


}
