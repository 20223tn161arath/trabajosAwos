package mx.edu.utez.ordinario.model.clothes;

import mx.edu.utez.ordinario.model.Repository;
import mx.edu.utez.ordinario.utils.MySQLConnection;
import mx.edu.utez.ordinario.utils.Response;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoClothes implements Repository<BeanClothes> {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;
    MySQLConnection mysql = new MySQLConnection();

    private final String GET_CLOTHES = "SELECT * FROM clothes";
    private final String GET_CLOTHE = "SELECT * FROM clothes WHERE id = ?";
    private final String INSERT_CLOTHE = "INSERT INTO clothes(id,name,price,size,brand,stock,cloth_type, created_at,status, category_id, clothe_type_id) VALUES(?,?,?,?,?,?,?,?)";
    private final String UPDATE_CLOTHE = "UPDATE SET name = ?,price = ?,size = ?,brand = ?,stock = ?,cloth_type = ?,created_at = ?,status = ?, category_id, cloth_type_id = ? WHERE id = ?";

    @Override
    public Response<List> findAll() {

        List<BeanClothes> clothesList = new ArrayList<>();
        Response<List> response = new Response<>();
        BeanClothes clothes = null;
        try{
            conn = mysql.getConnection();
            String query = GET_CLOTHES;
            pstm = conn.prepareStatement(query);
            rs = pstm.executeQuery();
            while (rs.next()){
                clothes = new BeanClothes();
                clothes.setId(rs.getInt("id"));
                clothes.setName(rs.getString("Name"));
                clothes.setPrice(rs.getInt("price"));
                clothes.setSize(rs.getInt("size"));
                clothes.setBrand(rs.getString("brand"));
                clothes.setStock(rs.getInt("stock"));
                clothes.setCloth_type(rs.getString("cloth_type"));
                clothes.setStatus(rs.getInt("status"));
                clothes.setCategory_id(rs.getInt("category_id"));
                clothes.setClothe_type_id(rs.getInt("clothe_type_id"));
                clothesList.add(clothes);
            }
            if(clothesList.isEmpty()){
                response.setError(false);
                response.setStatus(200);
                response.setMessage("Nothing Found");
                response.setData(null);
            }else{
                response.setError(false);
                response.setStatus(200);
                response.setMessage("OK");
                response.setData(clothesList);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoClothes.class.getName())
                    .log(Level.SEVERE, "Error -> findAll_DaoClothes " + e.getMessage());
            response.setError(true);
            response.setStatus(400);
            response.setMessage("Error -> " + e.getMessage());
            response.setData(null);
        }finally {
            mysql.close(conn, pstm, rs);
        }
        return response;
    }

    @Override
    public Response<BeanClothes> findOne(Long id) {
        Response<BeanClothes> response = new Response<>();
        BeanClothes clothes = null;
        try {
            conn = mysql.getConnection();
            String query = GET_CLOTHE;
            pstm = conn.prepareStatement(query);
            pstm.setLong(1,id);
            rs = pstm.executeQuery();
            if(rs.next()){
                clothes = new BeanClothes();
                clothes.setId(rs.getInt("id"));
                clothes.setName(rs.getString("name"));
                clothes.setPrice(rs.getInt("price"));
                clothes.setSize(rs.getInt("size"));
                clothes.setBrand(rs.getString("brand"));
                clothes.setStock(rs.getInt("stock"));
                clothes.setCloth_type(rs.getString("cloth_type"));
                clothes.setCreated_at(rs.getString("Created_at"));
                clothes.setStatus(rs.getInt("status"));
                clothes.setCategory_id(rs.getInt("category_id"));
                clothes.setClothe_type_id(rs.getInt("clothe_type_id"));

                response.setError(false);
                response.setStatus(200);
                response.setMessage("OK");
                response.setData(clothes);
            }else{
                response.setError(false);
                response.setStatus(200);
                response.setMessage("Nothing Found");
                response.setData(null);
            }

        }catch (SQLException e){
            Logger.getLogger(DaoClothes.class.getName())
                    .log(Level.SEVERE, "Error -> findOne_DaoClothes " + e.getMessage());

            response.setError(true);
            response.setStatus(400);
            response.setMessage("Error -> " + e.getMessage());
            response.setData(null);
        }finally {
            mysql.close(conn, pstm, rs);
        }
        return response;
    }

    @Override
    public Response<BeanClothes> save(BeanClothes clothes) {
        Response<BeanClothes> response = new Response<>();
        try {
            conn = mysql.getConnection();
            String query = INSERT_CLOTHE;
            pstm = conn.prepareStatement(query);
            pstm.setLong(1, clothes.getId());
            pstm.setInt(2, clothes. getPrice());
            pstm.setInt(3, clothes.getSize());
            pstm.setString(4, clothes.getBrand());
            pstm.setInt(5, clothes.getStock());
            pstm.setString(6,   clothes.getCloth_type());
            pstm.setString(7,   clothes.getCreated_at());
            pstm.setInt(8, clothes.getStatus());
            pstm.setInt(8, clothes.getCategory_id());
            pstm.setInt(8, clothes.getClothe_type_id());
            if (pstm.executeUpdate() == 1){
                response.setError(false);
                response.setStatus(200);
                response.setMessage("OK");
                response.setData(clothes);
            }else{
                response.setError(false);
                response.setStatus(200);
                response.setMessage("Error to save");
                response.setData(null);
            }
        }catch (SQLException e){
                Logger.getLogger(DaoClothes.class.getName())
                        .log(Level.SEVERE, "Error -> save_DaoClothes " + e.getMessage());

                response.setError(true);
                response.setStatus(400);
                response.setMessage("Error -> " + e.getMessage());
                response.setData(null);
            }finally{
            mysql.close(conn, pstm, rs);
        }
        return response;
    }

    @Override
    public Response<BeanClothes> update(BeanClothes object) {
        return null;
    }

    @Override
    public Response<BeanClothes> delete(Long id) {
        return null;
    }
}
